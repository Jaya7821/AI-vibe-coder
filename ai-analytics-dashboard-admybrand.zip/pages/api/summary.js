export default async function handler(req, res) {
  const summary = "Based on current data, user activity increased by 30% in Q2...";
  res.status(200).json({ summary });
}