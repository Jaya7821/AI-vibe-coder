# AI-Powered Analytics Dashboard

A modern analytics dashboard with AI-powered summary using Next.js, Tailwind CSS, and Recharts.